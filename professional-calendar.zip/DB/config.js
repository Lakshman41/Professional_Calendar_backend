const { Client } = require('pg');
//const client = new Client({
//     host: 'localhost',           // usually 'localhost' for local setup
//     port: 5432,                  // PostgreSQL default port
//     user: 'postgres',       // your PostgreSQL username
//     password: '123456',   // your PostgreSQL password
//     database: 'Calendar',   // your PostgreSQL database name
// });

// client.connect()
//   .then(() => console.log("Connected to PostgreSQL!"))
//   .catch((err) => console.error("Connection error", err.stack));